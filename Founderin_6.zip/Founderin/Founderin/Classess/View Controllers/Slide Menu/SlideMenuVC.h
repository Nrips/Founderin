//
//  SlideMenuVC.h
//  Founderin
//
//  Created by Neuron on 12/2/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideMenuVC : UIViewController

@property (strong, nonatomic) IBOutlet UITableView *tblMenu;

@end