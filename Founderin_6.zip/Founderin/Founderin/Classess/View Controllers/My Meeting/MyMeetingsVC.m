//
//  MyMeetingsVC.m
//  Founderin
//
//  Created by Neuron on 12/3/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "MyMeetingsVC.h"

#import "SlideMenuVC.h"

@interface MyMeetingsVC ()

@property (weak, nonatomic) IBOutlet UIView         *viewMain;
@property (weak, nonatomic) IBOutlet UIView         *viewSideMenu;

@property (weak, nonatomic) IBOutlet UIImageView    *imgViewHeader;

@property (weak, nonatomic) IBOutlet UIButton       *btnSideMenu;
@property (weak, nonatomic) IBOutlet UIButton       *btnMeetings;
@property (weak, nonatomic) IBOutlet UIButton       *btnInvites;

@end

@implementation MyMeetingsVC

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    [self addSlideView];
}

#pragma mark - Custom Methods
- (void)addSlideView
{
    SlideMenuVC *nonSystemsController = [self.storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([SlideMenuVC class])];
    
    nonSystemsController.view.frame = self.viewSideMenu.bounds;
    [self.viewSideMenu addSubview:nonSystemsController.view];
    [nonSystemsController didMoveToParentViewController:self];
    [self addChildViewController:nonSystemsController];
}

#pragma mark - Action Methods
- (IBAction)btnSlideMenu_Action:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        //--->    Show Menu View
        self.btnSideMenu.tag = 1;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(270, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
    else
    {
        //--->    Hide Menu View
        self.btnSideMenu.tag = 0;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(0, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
}

- (IBAction)btnMeetings_Action:(id)sender
{
    self.imgViewHeader.image     = [UIImage imageNamed:@"tabbar_meetings"];
    
    if (self.btnMeetings.selected)
    {
        self.btnMeetings.selected    = !self.btnMeetings.selected;
    }
    self.btnInvites.selected = NO;
}

- (IBAction)btnInvites_Action:(id)sender
{
    self.imgViewHeader.image     = [UIImage imageNamed:@"tabbar_invites"];

    if (!self.btnInvites.selected)
    {
        self.btnInvites.selected    = !self.btnInvites.selected;
    }
    self.btnMeetings.selected = YES;
}

#pragma mark - Memory Warning
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end