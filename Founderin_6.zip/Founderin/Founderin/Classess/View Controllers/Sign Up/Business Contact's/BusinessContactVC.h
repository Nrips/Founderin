//
//  BusinessContactVC.h
//  Founderin
//
//  Created by Neuron on 12/1/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BusinessContactVC : UIViewController

@end
