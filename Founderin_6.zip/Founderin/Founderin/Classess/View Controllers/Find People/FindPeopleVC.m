//
//  FindPeopleVC.m
//  Founderin
//
//  Created by Neuron on 11/22/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "FindPeopleVC.h"

#import "FindPeopleCell.h"
#import "SlideMenuVC.h"
#import "SearchFilterCell.h"

@interface FindPeopleVC () <UITableViewDelegate, UITableViewDataSource>
{
    UISwipeGestureRecognizer    *swipeMenuLeft;
    UISwipeGestureRecognizer    *swipeMenuRight;
}

@property (weak, nonatomic) IBOutlet UIView             *viewMain;
@property (weak, nonatomic) IBOutlet UIView             *viewSideMenu;
@property (weak, nonatomic) IBOutlet UIView             *viewSearchFilter;

@property (weak, nonatomic) IBOutlet UIButton           *btnSideMenu;
@property (weak, nonatomic) IBOutlet UIButton           *btnSearchFilter;

@property (weak, nonatomic) IBOutlet UICollectionView   *collectionView;

@property (weak, nonatomic) IBOutlet UITableView        *tblViewSearchFilter;

@end

@implementation FindPeopleVC

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //---> Do any additional setup after loading the view.
    
    //--->    Add SwipeGestureRecognizer
    swipeMenuLeft               = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeToLeft)];
    [swipeMenuLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [[self view] addGestureRecognizer:swipeMenuLeft];
    
    swipeMenuRight              = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeToRight)];
    [swipeMenuRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [[self view] addGestureRecognizer:swipeMenuRight];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    [self addSlideView];
    
    // Configure Uicollectionview layout
    UICollectionViewFlowLayout *flowLayout =[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setItemSize:CGSizeMake(deviceWidth, 500)];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    [self.collectionView setCollectionViewLayout:flowLayout];
}

#pragma mark - Custom Methods
- (void)addSlideView
{
    SlideMenuVC *nonSystemsController = [self.storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([SlideMenuVC class])];
    
    nonSystemsController.view.frame = self.viewSideMenu.bounds;
    [self.viewSideMenu addSubview:nonSystemsController.view];
    [nonSystemsController didMoveToParentViewController:self];
    [self addChildViewController:nonSystemsController];
}

- (void)handleSwipeToLeft
{
    self.btnSideMenu.tag = 0;
    [UIView animateWithDuration:0.5 animations:^(void){
        [self.viewMain setFrame:CGRectMake(0, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height)];
    }];
}

- (void)handleSwipeToRight
{
    self.btnSideMenu.tag = 1;
    [UIView animateWithDuration:0.5 animations:^(void){
        [self.viewMain setFrame:CGRectMake(270, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height)];
    }];
}

- (void)handleSwipeRight:(UISwipeGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView: self.collectionView];
    NSIndexPath *indexPath = [self.collectionView indexPathForItemAtPoint:p];
    
    if (indexPath != nil)
    {
        NSInteger countt = indexPath.row + 1;
        FindPeopleCell* cell = (FindPeopleCell *) [self.collectionView cellForItemAtIndexPath:indexPath];
        if (cell)
        {
            [self snapToCellAtIndexRight:countt withAnimation:YES];//paas index here to move to.
        }
    }
}

- (void)handleSwipeLeft:(UISwipeGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView: self.collectionView];
    NSIndexPath *indexPath = [self.collectionView indexPathForItemAtPoint:p];
    
    if (indexPath != nil)
    {
        NSInteger swipeLeft = indexPath.row;
        swipeLeft --;
        
        FindPeopleCell* cell = (FindPeopleCell *)[self.collectionView cellForItemAtIndexPath:indexPath];
        if (cell)
        {
            [self snapToCellAtIndexLeft:swipeLeft withAnimation:YES];//paas index here to move to.
        }
    }
}

- (void)snapToCellAtIndexLeft:(NSInteger)index withAnimation:(BOOL)animated
{
    NSIndexPath *IndexPath = [NSIndexPath indexPathForRow:index inSection:0];
    [self.collectionView scrollToItemAtIndexPath:IndexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:animated];
    
    CGRect frame;
    frame.origin.x = self.collectionView.frame.size.width * index;
    frame.origin.y = 0;
    frame.size = self.collectionView.frame.size;
    [self.collectionView setContentSize:CGSizeMake(self.collectionView.frame.size.width * index, self.collectionView.frame.size.height)];
}

- (void)snapToCellAtIndexRight:(NSInteger)index withAnimation:(BOOL)animated
{
    NSIndexPath *IndexPath = [NSIndexPath indexPathForRow:index inSection:0];
    [self.collectionView scrollToItemAtIndexPath:IndexPath atScrollPosition:UICollectionViewScrollPositionRight animated:animated];
    
    CGRect frame;
    frame.origin.x = self.collectionView.frame.size.width * index;
    frame.origin.y = 0;
    frame.size = self.collectionView.frame.size;
    [self.collectionView setContentSize:CGSizeMake(self.collectionView.frame.size.width * index, self.collectionView.frame.size.height)];
}

#pragma mark - Action Methods
/**
 **     Show/Hide menu view with animation on tap of menu button
 **/
- (IBAction)btnSlideMenu_Action:(UIButton *)sender
{
    self.viewSearchFilter.hidden = YES;
    self.viewSideMenu.hidden = NO;
    
    if (sender.tag == 0)
    {
        //--->    Show Menu View
        self.btnSideMenu.tag = 1;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(270, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
    else
    {
        //--->    Hide Menu View
        self.btnSideMenu.tag = 0;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(0, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
}

- (IBAction)btnSearchFilter_Action:(UIButton *)sender
{
    self.viewSearchFilter.hidden = NO;
    self.viewSideMenu.hidden = YES;

    if (sender.tag == 0)
    {
        //--->    Show Menu View
        self.btnSearchFilter.tag = 1;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(-270, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
    else
    {
        //--->    Hide Menu View
        self.btnSearchFilter.tag = 0;
        [UIView animateWithDuration:0.5 animations:^(void){
            [self.viewMain setFrame:CGRectMake(0, 0, self.viewMain.frame.size.width, self.viewMain.frame.size.height + 20)];
        }];
    }
}

#pragma mark - UITableview DataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //*>    Initialize header view object
    
    UIView *viewHeader              = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 35)];
    
    UIImageView *imgViewUser        = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 35)];
    imgViewUser.image               = [UIImage imageNamed:@"section_row.png"];
    
    UILabel *lblSectionTitle            = [[UILabel alloc] initWithFrame:CGRectMake(15, 5, 280, 25)];
    lblSectionTitle.backgroundColor     = [UIColor clearColor];
    lblSectionTitle.textColor           = [UIColor darkGrayColor];
    lblSectionTitle.font                = [UIFont fontWithName:@"Helvetica-Neue" size:21.0];

    if (section == 0)
    {
        lblSectionTitle.text                = @"Date & Time";
    }
    else if (section == 1)
    {
        lblSectionTitle.text                = @"Location";
    }
    else if (section == 2)
    {
        lblSectionTitle.text                = @"Interest";
    }
    
    [viewHeader addSubview:imgViewUser];
    [viewHeader addSubview:lblSectionTitle];
    
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 35;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 3;
    }
    else if (section == 1)
    {
        return 1;
    }
    else
    {
        return 2;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SearchFilterCell";
    SearchFilterCell *cell = (SearchFilterCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        cell = [[SearchFilterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier] ;
    }
    
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"day"];
            cell.lblSearchTitle.text     = @"Day";
            cell.btnSearcgResult.titleLabel.text = @"Select Day";
        }
        else if (indexPath.row == 1)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"time"];
            cell.lblSearchTitle.text     = @"Start";
            cell.btnSearcgResult.titleLabel.text = @"Select Start Time";
        }
        else if (indexPath.row == 2)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"time"];
            cell.lblSearchTitle.text     = @"End";
            cell.btnSearcgResult.titleLabel.text = @"Select End Time";
        }
    }
    else if (indexPath.section == 1)
    {
        if (indexPath.row == 0)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"city"];
            cell.lblSearchTitle.text     = @"City";
            cell.btnSearcgResult.titleLabel.text = @"Select Location";
        }
    }
    else if (indexPath.section == 2)
    {
        if (indexPath.row == 0)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"industry_search"];
            cell.lblSearchTitle.text     = @"Industry";
            cell.btnSearcgResult.titleLabel.text = @"Any";
        }
        if (indexPath.row == 1)
        {
            cell.imgViewSearchIcon.image = [UIImage imageNamed:@"purpose"];
            cell.lblSearchTitle.text     = @"Purpose";
            cell.btnSearcgResult.titleLabel.text = @"Any";
        }
    }
    
    return cell;
}

#pragma mark - UITableview Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark UICollectionview Data source And Delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return self.collectionView.frame.size;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 5;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier         = @"FindPeopleCell";
    
    FindPeopleCell *cell            = (FindPeopleCell *)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    UISwipeGestureRecognizer *swipeLeftt = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight:)];
    UISwipeGestureRecognizer *swipeRightt = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeLeft:)];
    
    [swipeLeftt setNumberOfTouchesRequired:1];
    [swipeLeftt setDirection:UISwipeGestureRecognizerDirectionLeft];
    [swipeRightt setNumberOfTouchesRequired:1];
    [swipeRightt setDirection:UISwipeGestureRecognizerDirectionRight];
    
    [cell.contentView addGestureRecognizer:swipeLeftt];
    [cell.contentView addGestureRecognizer:swipeRightt];
    
    return cell;
}

#pragma mark - Memory Warning
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    [self removeFromParentViewController];
}

@end