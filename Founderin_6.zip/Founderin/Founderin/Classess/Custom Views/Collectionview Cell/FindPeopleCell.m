//
//  FindPeopleCell.m
//  Founderin
//
//  Created by Neuron on 12/2/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "FindPeopleCell.h"

@implementation FindPeopleCell

@synthesize lblAddress;
@synthesize lblUserName;

@end