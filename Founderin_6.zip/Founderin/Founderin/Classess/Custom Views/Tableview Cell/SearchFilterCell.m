//
//  SearchFilterCell.m
//  Founderin
//
//  Created by Neuron on 12/3/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "SearchFilterCell.h"

@implementation SearchFilterCell

@synthesize lblSearchTitle;
@synthesize btnSearcgResult;
@synthesize imgViewSearchIcon;

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end