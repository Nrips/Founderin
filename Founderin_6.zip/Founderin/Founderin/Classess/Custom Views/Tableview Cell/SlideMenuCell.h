//
//  SlideMenuCell.h
//  Founderin
//
//  Created by Neuron on 11/26/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideMenuCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UIImageView *imgViewMenuIcon;
@property (nonatomic, strong) IBOutlet UILabel *lblMenuTitle;

@end