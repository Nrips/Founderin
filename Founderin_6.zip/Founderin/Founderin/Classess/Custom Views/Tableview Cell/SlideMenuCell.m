//
//  SlideMenuCell.m
//  Founderin
//
//  Created by Neuron on 11/26/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "SlideMenuCell.h"

@implementation SlideMenuCell

@synthesize imageView;
@synthesize lblMenuTitle;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
